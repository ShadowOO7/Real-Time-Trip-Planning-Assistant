import os, json
def load_candidates(path):
    with open(path) as f:
        return json.load(f)
