DWE_full_prototype - PyTorch prototype for Dual-way Enhanced Framework (text-matching view)

Overview
--------
This repository contains a prototype implementation that closely follows the paper's design:
- Text encoders: BERT (for entity/Wikipedia descriptions) + CLIP text encoder (for mentions/context)
- Visual encoders: CLIP image encoder for global visual features + optional Faster-RCNN for object regions
- Cross-modal enhancer: a lightweight Transformer cross-attention module that fuses text and image features
- Ranking: Computes similarity between query (mention+context+visual) and candidate entity vectors, supports FAISS index for retrieval
- Training loop: example contrastive/triplet-style loss and evaluation code

Notes
-----
- This is a prototype. Running full experiments requires GPU(s).
- Many parts are modular and marked as TODO (replace with larger datasets / more complex attribute extractors).
- Face attributes and ANP extractors are provided as optional modules (requires facenet-pytorch and custom ANP code).

Quick start (create venv & install):
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```
Then adapt `configs` and dataset paths and run training or inference.

Files
-----
- model.py         : model components (CLIP, BERT, CrossModalEnhancer)
- dataloader.py    : Dataset and dataloader for the dummy dataset (mirrors DWE_toy structure)
- train.py         : training loop (single-GPU example)
- eval.py          : evaluation/inference script (builds FAISS index for candidates)
- utils.py         : helper utilities
- requirements.txt : packages to install
- README.md        : this file
