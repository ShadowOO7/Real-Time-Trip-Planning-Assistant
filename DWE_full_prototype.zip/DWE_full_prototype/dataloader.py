import os, json
from PIL import Image
from torch.utils.data import Dataset, DataLoader

class DWEDataset(Dataset):
    def __init__(self, samples_json, candidates_json, root_dir):
        with open(samples_json) as f:
            self.samples = json.load(f)
        with open(candidates_json) as f:
            self.candidates = json.load(f)
        self.root = root_dir

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        s = self.samples[idx]
        img_path = os.path.join(self.root, s['image']) if s.get('image') else None
        image = Image.open(img_path).convert('RGB') if img_path and os.path.exists(img_path) else None
        return {
            'id': s['id'],
            'mention': s['mention'],
            'context': s['text'],
            'image': image,
            'gt': s.get('gt')
        }

def collate_batch(batch):
    return batch

def build_dataloader(root_dir, batch_size=4):
    samples_json = os.path.join(root_dir, 'wikidiverse/dataset/samples.json')
    cands_json = os.path.join(root_dir, 'wikidiverse/dataset/cands/candidates.json')
    ds = DWEDataset(samples_json, cands_json, root_dir)
    return DataLoader(ds, batch_size=batch_size, collate_fn=collate_batch)
