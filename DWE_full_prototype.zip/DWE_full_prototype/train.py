import os, torch, argparse, json, time
from model import DWEModel
from dataloader import build_dataloader
from transformers import CLIPProcessor
import numpy as np
import faiss

def build_faiss_index(embeddings):
    d = embeddings.shape[1]
    index = faiss.IndexFlatIP(d)
    faiss.normalize_L2(embeddings)
    index.add(embeddings)
    return index

def main(root_dir, device='cuda'):
    device = torch.device(device if torch.cuda.is_available() else 'cpu')
    model = DWEModel(device=device).to(device)
    clip_processor = CLIPProcessor.from_pretrained('openai/clip-vit-base-patch32')
    dl = build_dataloader(root_dir, batch_size=4)
    # Load candidate descriptions & encode all to build FAISS index
    with open(os.path.join(root_dir, 'wikidiverse/dataset/cands/candidates.json')) as f:
        cands = json.load(f)
    cand_texts = [c['desc'] for c in cands]
    print('Encoding candidates (BERT)... This may take time.')
    cand_embs = model.forward_entity(cand_texts).cpu().numpy()
    index = build_faiss_index(cand_embs)
    # Loop over dataset (no heavy training here - example inference pass)
    results = []
    for batch in dl:
        mentions = [b['mention'] for b in batch]
        contexts = [b['context'] for b in batch]
        images = [b['image'] for b in batch]
        q_emb = model.forward_query(mentions, contexts, images, clip_processor)
        q_np = q_emb.detach().cpu().numpy().astype('float32')
        faiss.normalize_L2(q_np)
        D, I = index.search(q_np, 10)
        for bi, b in enumerate(batch):
            top_ids = [cands[i]['id'] for i in I[bi]]
            results.append({'sample': b['id'], 'gt': b.get('gt'), 'pred_top10': top_ids})
    # Save results
    with open(os.path.join(root_dir, 'full_results.json'),'w') as f:
        json.dump(results, f, indent=2)
    print('Saved full_results.json')

if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=str, default='/mnt/data/DWE_toy')
    p.add_argument('--device', type=str, default='cuda')
    args = p.parse_args()
    main(args.root, args.device)
