# ================= analyze_results.py =================
import os, json
import numpy as np
import matplotlib.pyplot as plt

def load_results(root):
    path = os.path.join(root, 'eval_results_ext.json')
    with open(path) as f:
        return json.load(f)

def ensure_dir(d):
    if not os.path.exists(d):
        os.makedirs(d)

def metrics_table(summary):
    print("\n=== Metrics ===")
    print(f"Samples          : {summary['num_samples']}")
    print(f"Missing images   : {summary['missing_images']}")
    print(f"Elapsed (sec)    : {summary['elapsed_sec']:.2f}")
    print("")
    print("Recall@1/5/10 (Fused/Text/Image):")
    print(f"  Fused : {summary['recall@1_fused']:.3f} / {summary['recall@5_fused']:.3f} / {summary['recall@10_fused']:.3f}")
    print(f"  Text  : {summary['recall@1_text']:.3f} / {summary['recall@5_text']:.3f} / {summary['recall@10_text']:.3f}")
    print(f"  Image : {summary['recall@1_image']:.3f} / {summary['recall@5_image']:.3f} / {summary['recall@10_image']:.3f}")
    print("")
    print("MRR (Fused/Text/Image):")
    print(f"  {summary['mrr_fused']:.3f} / {summary['mrr_text']:.3f} / {summary['mrr_image']:.3f}")

def plot_recall(summary, outdir):
    ks = ['recall@1', 'recall@5', 'recall@10']
    fused = [summary[k+'_fused'] for k in ks]
    text  = [summary[k+'_text']  for k in ks]
    image = [summary[k+'_image'] for k in ks]

    x = np.arange(len(ks))
    width = 0.25

    plt.figure()
    plt.bar(x - width, fused, width, label='Fused')
    plt.bar(x,         text,  width, label='Text')
    plt.bar(x + width, image, width, label='Image')
    plt.xticks(x, ks)
    plt.ylim(0, 1)
    plt.title('Recall@K')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, 'recall_at_k.png'))
    plt.close()

    # MRR
    plt.figure()
    vals = [summary['mrr_fused'], summary['mrr_text'], summary['mrr_image']]
    plt.bar(['Fused','Text','Image'], vals)
    plt.ylim(0, 1)
    plt.title('MRR')
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, 'mrr.png'))
    plt.close()

def plot_rank_hist(results, outdir):
    ranks = [r['rank_fused'] for r in results if r['rank_fused'] is not None]
    if len(ranks) == 0:
        ranks = [10]  # avoid empty
    plt.figure()
    plt.hist(ranks, bins=11, range=(-0.5, 10.5))
    plt.title('Ground-truth Rank Distribution (Fused)')
    plt.xlabel('Rank (0=Top1)')
    plt.ylabel('Count')
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, 'rank_hist_fused.png'))
    plt.close()

def plot_missing_images(results, outdir):
    had = sum(1 for r in results if r['had_image'])
    no  = sum(1 for r in results if not r['had_image'])
    plt.figure()
    plt.bar(['Has image','No image'], [had, no])
    plt.title('Image Availability')
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, 'image_availability.png'))
    plt.close()

def main(root):
    data = load_results(root)
    summary = data['summary']
    results = data['results']
    metrics_table(summary)

    outdir = os.path.join(root, 'plots')
    ensure_dir(outdir)

    plot_recall(summary, outdir)
    plot_rank_hist(results, outdir)
    plot_missing_images(results, outdir)
    print(f"\nSaved charts to: {outdir}")

if __name__ == '__main__':
    import argparse
    import torch

    p = argparse.ArgumentParser()
    p.add_argument("--root", type=str, required=True, help="Path to dataset root")
    p.add_argument("--device", type=str, default=None,
                   help="Device to run on (cuda or cpu). If not set, auto-detects.")
    args = p.parse_args()

    # Auto-detect device if not specified
    if args.device is None:
        args.device = "cuda" if torch.cuda.is_available() else "cpu"

    print(f"Using device: {args.device}")
    main(args.root, args.device)

# ======================================================
