import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import CLIPModel, CLIPProcessor, AutoModel, AutoTokenizer
from torchvision.models.detection import fasterrcnn_resnet50_fpn

class CrossModalEnhancer(nn.Module):
    """Cross-attention module where modalities attend to each other."""
    def __init__(self, dim, nhead=8, num_layers=2, dropout=0.1):
        super().__init__()
        encoder_layer = nn.TransformerEncoderLayer(d_model=dim, nhead=nhead, dropout=dropout, batch_first=False)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.proj = nn.Linear(dim, dim)

    def forward(self, x):  # x: (S, B, D) sequence-first
        y = self.transformer(x)
        # pooled (mean over sequence), output shape (B, D)
        y = y.mean(dim=0)
        return self.proj(y)


class DWEModel(nn.Module):
    def __init__(self, device='cuda'):
        super().__init__()
        self.device = device

        # CLIP encoders (image + text)
        self.clip = CLIPModel.from_pretrained('openai/clip-vit-base-patch32')
        self.clip.eval()  # frozen by default

        # BERT for richer entity/Wikipedia description encoding
        self.entity_encoder = AutoModel.from_pretrained('bert-base-uncased')
        self.entity_tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')

        # Optional object detector
        try:
            self.detector = fasterrcnn_resnet50_fpn(weights="DEFAULT").to(device)
            self.detector.eval()
        except Exception as e:
            print('Warning: detector unavailable; region features disabled:', e)
            self.detector = None

        # Dimension setup (CLIP already projects to 512-dim)
        common_dim = 512
        self.entity_proj = nn.Linear(self.entity_encoder.config.hidden_size, common_dim)
        self.enhancer = CrossModalEnhancer(dim=common_dim, nhead=8, num_layers=2)
        self.final_proj = nn.Linear(common_dim, common_dim)

    def encode_image(self, images, processor):
        """Encode image(s) with CLIP, output (B, 512)."""
        inputs = processor(images=images, return_tensors='pt').to(self.device)
        with torch.no_grad():
            clip_out = self.clip.get_image_features(**inputs)  # already 512-d
        z = F.normalize(clip_out, dim=-1)
        return z

    def encode_text_clip(self, texts, processor):
        """Encode short texts with CLIP, output (B, 512)."""
        inputs = processor(text=texts, return_tensors='pt', padding=True).to(self.device)
        with torch.no_grad():
            clip_txt = self.clip.get_text_features(**inputs)  # already 512-d
        z = F.normalize(clip_txt, dim=-1)
        return z

    def encode_entity(self, texts):
        """Encode long entity descriptions with BERT -> project -> normalize."""
        tok = self.entity_tokenizer(texts, padding=True, truncation=True, return_tensors='pt').to(self.device)
        with torch.no_grad():
            out = self.entity_encoder(**tok)
        cls = out.last_hidden_state[:, 0, :]  # [CLS]
        z = self.entity_proj(cls)
        z = F.normalize(z, dim=-1)
        return z

    def forward_query(self, mention_texts, context_texts, images, clip_processor):
        """Build query embedding from mention, context, and optional image."""
        txt_inputs = [m if m is not None else "" for m in context_texts]
        clip_txt = self.encode_text_clip(txt_inputs, clip_processor)  # (B, 512)

        if images is not None:
            clip_img = self.encode_image(images, clip_processor)  # (B, 512)
        else:
            clip_img = torch.zeros_like(clip_txt)

        # Concatenate as a 2-step sequence (text + image)
        seq = torch.stack([clip_txt, clip_img], dim=0)  # (2, B, 512)
        enhanced = self.enhancer(seq)  # (B, 512)
        enhanced = self.final_proj(enhanced)
        enhanced = F.normalize(enhanced, dim=-1)
        return enhanced

    def forward_entity(self, entity_texts):
        return self.encode_entity(entity_texts)