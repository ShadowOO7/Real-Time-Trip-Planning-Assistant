# ================= dataset_stats.py =================
import os, json
import numpy as np

def main(root):
    with open(os.path.join(root, 'wikidiverse/dataset/cands/candidates.json')) as f:
        cands = json.load(f)
    with open(os.path.join(root, 'wikidiverse/dataset/samples.json')) as f:
        samples = json.load(f)

    desc_lens = [len(c.get('desc','').split()) for c in cands]
    ctx_lens  = [len(s.get('text','').split()) for s in samples]

    print("Candidates:", len(cands))
    print("Samples   :", len(samples))
    print("Desc length (avg/med):", np.mean(desc_lens), np.median(desc_lens))
    print("Ctx  length (avg/med):", np.mean(ctx_lens),  np.median(ctx_lens))

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=str, required=True)
    args = p.parse_args()
    main(args.root)
# ====================================================
